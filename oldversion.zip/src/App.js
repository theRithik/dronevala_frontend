import React, { Suspense, lazy } from "react";
import { BrowserRouter, Route, Routes} from 'react-router-dom';
import './global.css';
import RouteError from "./errors/routeError";
import ErrorBoundary from "antd/es/alert/ErrorBoundary";

const CommonRoutes =lazy(()=>import('./routes/commonRoutes'))
const VendorRoutes = lazy(()=>import ('./routes/vendorRoutes'))


function App() {
  return (
    <>
    <ErrorBoundary>
    <Suspense fallback={<RouteError/>}>
    <BrowserRouter>
    <Routes>
      <Route path='/*' element={<CommonRoutes/>}/>
      <Route path='/vendor/*' element={<VendorRoutes/>}/>
    </Routes>
    </BrowserRouter>
    </Suspense>
    </ErrorBoundary>
    </>
  
  );
}
 

export default App;
