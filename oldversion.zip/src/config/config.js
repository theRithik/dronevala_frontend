const baseurl ="https://lqeiv6e0eh.execute-api.ap-south-1.amazonaws.com/prod"

const endpoints={
   url:baseurl,
   aws:"https://dronevala.com/api/aws/upload",
//    Academy....................
venderDetails:"/admin/ADetails",
addCourse:"/admin/addCourse",
findCourses:"/admin/findCourse",
updateCourse:"/admin/updateCourse",
updateImage:"",
addTrainer:"/admin/addTrainer",
addSyllabus:"/admin/addSyllabus",
addGallery:"",
addViedo:"",
updateCourseDate:"/admin/courseStartDate",

}

export default endpoints