import React from "react";

const RouteError=()=>{
    return(
        <>
        <h1>Loading..........</h1>
        </>
    )
}
export default RouteError