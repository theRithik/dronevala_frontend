import React, { Suspense, lazy } from "react";
import { Route, Routes } from "react-router-dom";
import RouteError from "../errors/routeError";
import ErrorBoundary from "antd/es/alert/ErrorBoundary";
import Service from "../services/services";

const Home=lazy(()=>import("../home/home"))
const Academy =lazy(()=>import("../Academy/academy"))
const AcadDetails = lazy(()=>import("../Academy/acadDetails"))
const UserLogin=lazy(()=>import("../Ulogin/login"))
const UserRegister=lazy(()=>import("../Ulogin/register"))
const AcdBooking=lazy(()=>import("../Academy/AcdBooking"))
const Header = lazy(()=>import("../home/HF/header"))
const About =lazy(()=>import("../home/about/aboutus"))

const CommonRoutes =()=>{
    return(
        <>
        <ErrorBoundary>
        <Suspense fallback={<RouteError/>}>
        <Routes>
            <Route element={<Header/>}>
            <Route index path="/" element={<Home/>}/>
            <Route path="/login" element={<UserLogin/>}/>
            <Route path="/register" element={<UserRegister/>}/>
            <Route path="/academy" element={<Academy/>}/>
            <Route path="/academy/:institute/:course/:id" element={<AcadDetails/>}/>
            <Route path="/academy/course/booking" element={<AcdBooking/>}/>
            <Route path="/services" element={<Service/>}/>
            <Route path="/aboutus" element={<About/>}/>
            </Route>
        </Routes>
        </Suspense>
        </ErrorBoundary>
        </>
    )
}

export default CommonRoutes